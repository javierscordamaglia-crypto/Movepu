# 🌿 EcoSync - Progetto Unity 6.3

Gioco di raccolta risorse con sistema di risonanza e ciclo giornaliero.

## 📁 Struttura Cartelle

```
EcoSync-Game/
├── Assets/
│   ├── Scripts/
│   │   ├── Core/
│   │   │   ├── GameManager.cs
│   │   │   ├── WorldClock.cs
│   │   │   └── UIManager.cs
│   │   ├── Player/
│   │   │   ├── FirstPersonController.cs
│   │   │   ├── PlayerResonance.cs
│   │   │   ├── PlayerInteractor.cs
│   │   │   └── CameraSwitcher.cs
│   │   ├── World/
│   │   │   └── Collectible3D.cs
│   │   └── Utilities/
│   │       └── HandSway.cs
│   ├── Prefabs/
│   │   ├── Player.prefab
│   │   └── Collectible_Crystal.prefab
│   ├── Materials/
│   │   ├── Ground.mat
│   │   ├── Crystal_Normal.mat
│   │   └── Crystal_Sync.mat
│   └── Scenes/
│       └── MainScene.unity
└── README.md
```

## ⚙️ Configurazione in Unity

### 1. Creare il Player

1. Crea un GameObject vuoto chiamato **"Player"**
2. Aggiungi i seguenti componenti:
   - **CharacterController** (Radius: 0.5, Height: 2, Center: 0,1,0)
   - **FirstPersonController** (assign Main Camera nel campo `playerCamera`)
   - **PlayerResonance** (imposta Frequency: 1-9 dall'Inspector)
   - **PlayerInteractor**
   - **CameraSwitcher** (assign Main Camera e Hands)

### 2. Configurare la Main Camera

1. Crea un figlio del Player chiamato **"Main Camera"**
2. Posizione iniziale: `(0, 0, 0)`
3. Tag: `"MainCamera"`

### 3. Creare le Mani (Hands)

1. Crea un figlio della Main Camera chiamato **"Hands"**
2. Aggiungi due Cylinder come figli di Hands:
   - **LeftArm** (NO Collider)
   - **RightArm** (NO Collider)
3. Aggiungi lo script **HandSway** al GameObject Hands

### 4. Sistema WorldClock

1. Crea un GameObject vuoto chiamato **"WorldClock"**
2. Aggiungi lo script **WorldClock**
3. Imposta `dayDurationSeconds: 300` (5 minuti)

### 5. GameManager

1. Crea un GameObject vuoto chiamato **"GameSystem"**
2. Aggiungi lo script **GameManager**

### 6. UI Manager

1. Crea un Canvas (GameObject → UI → Canvas)
2. Aggiungi 4 TextMeshProUGUI:
   - `syncText` - Mostra stato SYNC
   - `collectFeedbackText` - Feedback raccolta
   - `dayInfoText` - Giorno corrente
   - `playerFreqText` - Frequenza player
3. Crea un GameObject vuoto **"UIManager"** con script **UIManager**
4. Assegna i riferimenti TextMeshProUGUI nell'Inspector

### 7. Terreno (Ground)

1. Crea un Plane (GameObject → 3D Object → Plane)
2. Scala: `(10, 1, 10)`
3. Assegna il materiale **Ground.mat**

### 8. Collectible (Cristallo)

1. Crea una Sphere o Cylinder
2. Aggiungi lo script **Collectible3D**
3. Configura:
   - `resourceName`: "Cristallo"
   - `baseAmount`: 10
   - `normalMaterial`: Crystal_Normal.mat
   - `syncMaterial`: Crystal_Sync.mat
4. Salva come Prefab in `Assets/Prefabs/Collectible_Crystal.prefab`

## 🎮 Controlli

| Tasto | Azione |
|-------|--------|
| W,A,S,D | Movimento |
| Mouse Orizzontale | Ruota personaggio (Y-axis) |
| Mouse Verticale | Guarda su/giù (camera locale) |
| Spazio | Salto |
| Shift Sinistro | Corsa |
| V | Toggle FPS/TPS |
| E | Raccogli oggetto |

## 🔧 Meccaniche Principali

### Resonance System
- Il player ha una **Frequency** (1-9) impostabile nell'Inspector
- Il **WorldClock** cambia giorno automaticamente ogni 5 minuti
- Se `Frequency == CurrentDay` → **SYNC ATTIVO** → bonus x2 sulle risorse

### Camera System
- **FPS**: Camera a (0, 1.6, 0) locale al player
- **TPS**: Camera orbita con LookAt sul busto
- Transizione fluida con Lerp
- Mani visibili in ENTRAMBE le modalità

### Collectibles
- Cristalli ruotano su se stessi
- Cambiano colore (oro) se player è in sync
- Raccolta con tasto E (distanza massima: 4m)
- Feedback UI con colore giallo se bonus attivo

## ✅ Test di Funzionamento

1. **Play** → Muovi mouse: il personaggio ruota sull'asse Y
2. **WASD** → Movimento relativo alla direzione del player
3. **Spazio** → Salto con gravità
4. **V** → Camera transizione fluida FPS ↔ TPS
5. **Mani** → Visibili in entrambe le modalità
6. **Avvicinati a cristallo + E** → Raccolta con bonus x2 se Frequency == WorldDay
7. **UI** → Mostra giorno corrente e stato sync

## 📝 Note Tecniche

- Tutti gli script usano Singleton pattern con check `Instance != null && Instance != this`
- `IsInSync` è una **proprietà** (chiamare senza parentesi: `player.IsInSync`)
- Codice formattato con 4 spazi per indentazione
- Compatibile con Unity 6.3

## 🚀 Pronto per l'uso!

Copia la cartella `EcoSync-Game` nel tuo progetto Unity o importala direttamente.
