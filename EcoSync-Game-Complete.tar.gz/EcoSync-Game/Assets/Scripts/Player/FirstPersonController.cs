using UnityEngine;

/// <summary>
/// Controller del personaggio basato su CharacterController.
/// Movimento stile Skyrim/GTA: il mouse ruota il personaggio sull'asse Y,
/// la camera guarda su/giù localmente. WASD muove relativo alla direzione del player.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class FirstPersonController : MonoBehaviour
{
    [Header("Camera")]
    public Transform playerCamera;
    
    [Header("Impostazioni Movimento")]
    public float walkSpeed = 5f;
    public float runSpeed = 8f;
    public float rotationSpeed = 10f;
    public float gravity = -20f;
    public float jumpHeight = 1.5f;

    [Header("Impostazioni Look")]
    public float mouseSensitivity = 2f;
    public float minPitch = -80f;
    public float maxPitch = 80f;

    private CharacterController _controller;
    private Vector3 _velocity;
    private float _xRotation = 0f;
    private bool _isGrounded;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
        
        if (playerCamera == null)
            playerCamera = Camera.main.transform;
    }

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        HandleLook();
        HandleMovement();
        HandleJump();
    }

    private void HandleLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        // Ruota il personaggio sull'asse Y (orizzontale)
        transform.Rotate(Vector3.up * mouseX);

        // Ruota la camera localmente sull'asse X (verticale) con clamp
        _xRotation -= mouseY;
        _xRotation = Mathf.Clamp(_xRotation, minPitch, maxPitch);

        if (playerCamera != null)
            playerCamera.localEulerAngles = new Vector3(_xRotation, 0f, 0f);
    }

    private void HandleMovement()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        bool isRunning = Input.GetKey(KeyCode.LeftShift);
        float currentSpeed = isRunning ? runSpeed : walkSpeed;

        // Movimento relativo alla direzione del personaggio
        Vector3 moveDirection = transform.right * horizontal + transform.forward * vertical;
        moveDirection.Normalize();

        _controller.Move(moveDirection * currentSpeed * Time.deltaTime);
    }

    private void HandleJump()
    {
        _isGrounded = _controller.isGrounded;

        if (_isGrounded && _velocity.y < 0f)
            _velocity.y = -2f;

        if (Input.GetButtonDown("Jump") && _isGrounded)
        {
            _velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        _velocity.y += gravity * Time.deltaTime;
        _controller.Move(_velocity * Time.deltaTime);
    }
}
