using UnityEngine;

/// <summary>
/// Gestisce l'interazione del player con gli oggetti del mondo.
/// Raycast dal centro dello schermo per raccogliere collectibles.
/// </summary>
[RequireComponent(typeof(PlayerResonance))]
public class PlayerInteractor : MonoBehaviour
{
    [Header("Interazione")]
    public float interactDistance = 4f;
    public KeyCode interactKey = KeyCode.E;

    private Camera _mainCamera;
    private PlayerResonance _playerResonance;

    private void Awake()
    {
        _mainCamera = Camera.main;
        _playerResonance = GetComponent<PlayerResonance>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(interactKey))
        {
            TryInteract();
        }
    }

    private void TryInteract()
    {
        if (_mainCamera == null)
            return;

        Ray ray = new Ray(_mainCamera.transform.position, _mainCamera.transform.forward);
        
        if (Physics.Raycast(ray, out RaycastHit hit, interactDistance))
        {
            Collectible3D collectible = hit.collider.GetComponent<Collectible3D>();
            
            if (collectible != null)
            {
                collectible.Collect(_playerResonance);
            }
        }
    }
}
