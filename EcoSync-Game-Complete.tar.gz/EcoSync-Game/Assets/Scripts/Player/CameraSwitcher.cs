using UnityEngine;

/// <summary>
/// Gestisce il cambio fluido tra camera in prima persona (FPS) e terza persona (TPS).
/// Le mani rimangono sempre visibili in entrambe le modalità.
/// </summary>
public class CameraSwitcher : MonoBehaviour
{
    [Header("Riferimenti")]
    public Transform playerCamera;
    public Transform hands;
    public Transform targetLook; // Punto sul busto del player per il LookAt in TPS

    [Header("Offset Camera")]
    public Vector3 fpsOffset = new Vector3(0f, 1.6f, 0f);
    public Vector3 tpsOffset = new Vector3(0f, 2.5f, -4f);

    [Header("Orbita TPS")]
    public float yawSpeed = 5f;
    public float pitchSpeed = 5f;
    public float minPitch = -30f;
    public float maxPitch = 60f;

    [Header("Transizione")]
    public KeyCode toggleKey = KeyCode.V;
    public float transitionSpeed = 5f;

    private bool _isFPS = true;
    private float _currentYaw = 0f;
    private float _currentPitch = 20f;
    private Vector3 _currentPosition;
    private Quaternion _currentRotation;

    private void Start()
    {
        if (playerCamera == null)
            playerCamera = Camera.main.transform;

        if (targetLook == null)
            targetLook = transform; // Usa il player come target se non assegnato

        _currentPosition = playerCamera.localPosition;
        _currentRotation = playerCamera.localRotation;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        if (Input.GetKeyDown(toggleKey))
        {
            _isFPS = !_isFPS;
        }

        HandleCameraMode();
    }

    private void HandleCameraMode()
    {
        if (_isFPS)
        {
            // Modalità FPS: camera fissa offset locale
            Vector3 targetPos = fpsOffset;
            playerCamera.localPosition = Vector3.Lerp(playerCamera.localPosition, targetPos, Time.deltaTime * transitionSpeed);
            playerCamera.localRotation = Quaternion.identity;

            // Mani visibili
            if (hands != null)
                hands.gameObject.SetActive(true);
        }
        else
        {
            // Modalità TPS: camera orbita intorno al player
            _currentYaw += Input.GetAxis("Mouse X") * yawSpeed;
            _currentPitch -= Input.GetAxis("Mouse Y") * pitchSpeed;
            _currentPitch = Mathf.Clamp(_currentPitch, minPitch, maxPitch);

            Quaternion rotation = Quaternion.Euler(_currentPitch, _currentYaw, 0f);
            Vector3 position = targetLook.position + rotation * tpsOffset;

            playerCamera.position = Vector3.Lerp(playerCamera.position, position, Time.deltaTime * transitionSpeed);
            playerCamera.LookAt(targetLook);

            // Mani sempre visibili anche in TPS
            if (hands != null)
                hands.gameObject.SetActive(true);
        }
    }
}
