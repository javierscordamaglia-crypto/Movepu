using System;
using UnityEngine;

/// <summary>
/// Gestisce la frequenza di risonanza del player e le statistiche.
/// La proprietà IsInSync verifica se la frequenza corrisponde al giorno corrente.
/// </summary>
public class PlayerResonance : MonoBehaviour
{
    [Header("Risonanza")]
    [Range(1, 9)]
    public int Frequency = 1;

    [Header("Statistiche")]
    public float Hunger = 100f;
    public float Thirst = 100f;
    public float Fatigue = 100f;
    public float Stress = 0f;

    [Header("Degrado Statistiche")]
    public float hungerDecay = 0.5f;
    public float thirstDecay = 0.7f;
    public float fatigueDecay = 0.3f;
    public float stressIncrease = 0.2f;

    /// <summary>
    /// True se la frequenza del player corrisponde al giorno corrente del WorldClock.
    /// </summary>
    public bool IsInSync
    {
        get
        {
            if (WorldClock.Instance == null)
                return false;
            return Frequency == WorldClock.Instance.CurrentDay;
        }
    }

    /// <summary>
    /// Evento chiamato quando le statistiche cambiano.
    /// </summary>
    public event Action OnStatsChanged;

    private void Update()
    {
        DegradeStats();
    }

    private void DegradeStats()
    {
        float delta = Time.deltaTime;

        Hunger -= hungerDecay * delta;
        Thirst -= thirstDecay * delta;
        Fatigue -= fatigueDecay * delta;
        
        if (!IsInSync)
            Stress += stressIncrease * delta;

        Hunger = Mathf.Clamp(Hunger, 0f, 100f);
        Thirst = Mathf.Clamp(Thirst, 0f, 100f);
        Fatigue = Mathf.Clamp(Fatigue, 0f, 100f);
        Stress = Mathf.Clamp(Stress, 0f, 100f);

        OnStatsChanged?.Invoke();
    }

    /// <summary>
    /// Imposta una nuova frequenza (1-9).
    /// </summary>
    public void SetFrequency(int newFreq)
    {
        Frequency = Mathf.Clamp(newFreq, 1, 9);
        OnStatsChanged?.Invoke();
    }
}
