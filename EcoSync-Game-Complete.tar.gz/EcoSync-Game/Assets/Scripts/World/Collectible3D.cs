using UnityEngine;

/// <summary>
/// Oggetto collezionabile 3D che ruota su se stesso.
/// Cambia materiale se il player è in sync e applica bonus alla raccolta.
/// </summary>
public class Collectible3D : MonoBehaviour
{
    [Header("Informazioni Risorsa")]
    public string resourceName = "Cristallo";
    public int baseAmount = 10;

    [Header("Materiali")]
    public Material normalMaterial;
    public Material syncMaterial;

    private MeshRenderer _meshRenderer;
    private bool _isCollected = false;

    private void Awake()
    {
        _meshRenderer = GetComponent<MeshRenderer>();
        UpdateMaterial();
    }

    private void Update()
    {
        // Rotazione continua del cristallo
        transform.Rotate(Vector3.up, 45f * Time.deltaTime);
        transform.Rotate(Vector3.forward, 20f * Time.deltaTime);

        UpdateMaterial();
    }

    /// <summary>
    /// Aggiorna il materiale in base allo stato di sync del player.
    /// </summary>
    private void UpdateMaterial()
    {
        if (_meshRenderer == null || _isCollected)
            return;

        PlayerResonance player = FindFirstObjectByType<PlayerResonance>();
        
        if (player != null && player.IsInSync)
        {
            if (syncMaterial != null)
                _meshRenderer.material = syncMaterial;
        }
        else
        {
            if (normalMaterial != null)
                _meshRenderer.material = normalMaterial;
        }
    }

    /// <summary>
    /// Raccolta dell'oggetto con calcolo del bonus.
    /// </summary>
    public void Collect(PlayerResonance player)
    {
        if (_isCollected)
            return;

        _isCollected = true;

        float multiplier = 1.0f;
        bool isBonus = false;

        if (player != null && GameManager.Instance != null)
        {
            multiplier = GameManager.Instance.GetBonusMultiplier(player.Frequency);
            isBonus = multiplier > 1.0f;
        }

        int finalAmount = Mathf.RoundToInt(baseAmount * multiplier);

        Debug.Log($"[Collectible] Raccolto: {resourceName} x{finalAmount} (Bonus: {isBonus})");

        // Feedback UI
        if (UIManager.Instance != null)
        {
            string feedbackText = $"+{finalAmount} {resourceName}";
            if (isBonus)
                feedbackText += " (SYNC BONUS!)";
            
            UIManager.Instance.ShowCollectFeedback(feedbackText, isBonus);
        }

        Destroy(gameObject);
    }
}
