using UnityEngine;

/// <summary>
/// Gestisce il movimento delle mani del player.
/// Applica sway basato sul mouse e bobbing durante il movimento.
/// </summary>
public class HandSway : MonoBehaviour
{
    [Header("Mouse Sway")]
    public float swayAmount = 0.5f;
    public float swaySmoothness = 10f;

    [Header("Movement Bobbing")]
    public float bobbingAmount = 0.1f;
    public float bobbingSpeed = 10f;
    public float walkThreshold = 0.1f;

    private Vector3 _originalPosition;
    private float _inputX;
    private float _inputY;
    private float _bobbingTimer;

    private void Start()
    {
        _originalPosition = transform.localPosition;
    }

    private void Update()
    {
        HandleSway();
        HandleBobbing();
    }

    private void HandleSway()
    {
        // Input mouse per lo sway
        _inputX = Mathf.Lerp(_inputX, Input.GetAxis("Mouse X"), Time.deltaTime * swaySmoothness);
        _inputY = Mathf.Lerp(_inputY, Input.GetAxis("Mouse Y"), Time.deltaTime * swaySmoothness);

        float swayX = -_inputX * swayAmount;
        float swayY = -_inputY * swayAmount;

        Vector3 targetPos = _originalPosition + new Vector3(swayX, swayY, 0f);
        transform.localPosition = Vector3.Lerp(transform.localPosition, targetPos, Time.deltaTime * swaySmoothness);
    }

    private void HandleBobbing()
    {
        // Controlla se il player si sta muovendo
        CharacterController controller = GetComponentInParent<CharacterController>();
        
        if (controller == null)
            return;

        bool isMoving = controller.velocity.magnitude > walkThreshold && controller.isGrounded;

        if (isMoving)
        {
            _bobbingTimer += Time.deltaTime * bobbingSpeed;
            
            float bobX = Mathf.Cos(_bobbingTimer) * bobbingAmount;
            float bobY = Mathf.Sin(_bobbingTimer) * bobbingAmount;

            transform.localPosition = new Vector3(
                _originalPosition.x + bobX,
                _originalPosition.y + bobY,
                _originalPosition.z
            );
        }
        else
        {
            _bobbingTimer = 0f;
            // Ritorna alla posizione originale con lerp
            transform.localPosition = Vector3.Lerp(transform.localPosition, _originalPosition, Time.deltaTime * 5f);
        }
    }
}
