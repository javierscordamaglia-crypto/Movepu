using UnityEngine;

/// <summary>
/// Singleton che gestisce il ciclo giornaliero del mondo.
/// Il giorno cambia automaticamente ogni dayDurationSeconds secondi.
/// </summary>
public class WorldClock : MonoBehaviour
{
    public static WorldClock Instance { get; private set; }

    [Tooltip("Durata di un giorno in secondi")]
    public float dayDurationSeconds = 300f;

    private float _timer;
    private int _currentDay = 1;

    /// <summary>
    /// Giorno corrente (1-9)
    /// </summary>
    public int CurrentDay => _currentDay;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        _timer += Time.deltaTime;

        if (_timer >= dayDurationSeconds)
        {
            _timer = 0f;
            _currentDay++;

            if (_currentDay > 9)
                _currentDay = 1;

            Debug.Log($"[WorldClock] Cambio giorno: {_currentDay}");
        }
    }
}
