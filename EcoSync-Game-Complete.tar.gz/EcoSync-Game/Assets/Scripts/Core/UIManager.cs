using UnityEngine;
using TMPro;

/// <summary>
/// Singleton che gestisce l'interfaccia utente.
/// Mostra informazioni su giorno, frequenza, sync e feedback raccolta.
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("Riferimenti UI")]
    public TextMeshProUGUI syncText;
    public TextMeshProUGUI collectFeedbackText;
    public TextMeshProUGUI dayInfoText;
    public TextMeshProUGUI playerFreqText;

    private float _feedbackTimer;
    private string _feedbackMessage = "";
    private Color _feedbackColor = Color.white;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Update()
    {
        UpdateMainUI();
        UpdateFeedback();
    }

    private void UpdateMainUI()
    {
        PlayerResonance playerRes = FindFirstObjectByType<PlayerResonance>();
        
        if (WorldClock.Instance != null && playerRes != null)
        {
            int currentDay = WorldClock.Instance.CurrentDay;
            int freq = playerRes.Frequency;
            bool isSync = playerRes.IsInSync;

            if (dayInfoText != null)
                dayInfoText.text = $"Giorno: {currentDay}/9";

            if (playerFreqText != null)
                playerFreqText.text = $"Frequenza: {freq}";

            if (syncText != null)
            {
                syncText.text = isSync ? "SYNC ATTIVO" : "NO SYNC";
                syncText.color = isSync ? Color.green : Color.red;
            }
        }
    }

    private void UpdateFeedback()
    {
        if (_feedbackTimer > 0f)
        {
            _feedbackTimer -= Time.deltaTime;

            if (collectFeedbackText != null)
            {
                collectFeedbackText.text = _feedbackMessage;
                collectFeedbackText.color = _feedbackColor;
            }
        }
        else
        {
            if (collectFeedbackText != null)
                collectFeedbackText.text = "";
        }
    }

    /// <summary>
    /// Mostra un messaggio di feedback temporaneo con colore condizionale.
    /// </summary>
    public void ShowCollectFeedback(string message, bool isBonus)
    {
        _feedbackMessage = message;
        _feedbackColor = isBonus ? Color.yellow : Color.white;
        _feedbackTimer = 2.5f;
    }
}
