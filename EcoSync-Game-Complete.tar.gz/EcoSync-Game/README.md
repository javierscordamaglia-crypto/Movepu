# EcoSync - Progetto Unity 6.3

Gioco di raccolta risorse con sistema di risonanza temporale.

## 📁 Struttura del Progetto

```
Assets/
├── Scripts/
│   ├── Core/
│   │   ├── GameManager.cs      # Singleton per bonus multiplier
│   │   ├── WorldClock.cs       # Ciclo giornaliero 1-9
│   │   └── UIManager.cs        # Interfaccia utente
│   ├── Player/
│   │   ├── FirstPersonController.cs  # Movimento Skyrim/GTA
│   │   ├── PlayerResonance.cs        # Frequenza e stats
│   │   ├── PlayerInteractor.cs       # Raycast interazione
│   │   └── CameraSwitcher.cs         # Toggle FPS/TPS
│   ├── World/
│   │   └── Collectible3D.cs    # Cristalli raccoglibili
│   └── Utilities/
│       └── HandSway.cs         # Sway e bobbing mani
├── Prefabs/
│   ├── Player.prefab
│   └── Collectible_Crystal.prefab
├── Materials/
│   ├── Ground.mat
│   ├── Crystal_Normal.mat
│   └── Crystal_Sync.mat
└── Scenes/
    └── MainScene.unity
```

## 🎮 Configurazione in Unity

### 1. Creare il Player

1. Crea GameObject vuoto chiamato "Player"
2. Aggiungi componenti:
   - **CharacterController** (Radius: 0.5, Height: 2, Center: 0,1,0)
   - **FirstPersonController** (assign Main Camera nel campo `playerCamera`)
   - **PlayerResonance** (imposta Frequency: 1-9 dall'Inspector)
   - **PlayerInteractor**
   - **CameraSwitcher** (assign Main Camera e Hands)

3. Come figlio di Player, crea "Main Camera":
   - Position: (0, 0, 0)
   - Tag: "MainCamera"

4. Come figlio di Main Camera, crea "Hands":
   - Aggiungi script **HandSway**
   - Posiziona modelli delle mani come figli di Hands

### 2. Sistema Mondiale

Crea GameObject vuoto "WorldSystem":
- Aggiungi script **WorldClock**
- Imposta `dayDurationSeconds: 300` (5 minuti)

Crea GameObject vuoto "GameSystem":
- Aggiungi script **GameManager**

### 3. UI Canvas

1. Crea Canvas (GameObject → UI → Canvas)
2. Aggiungi 4 TextMeshProUGUI:
   - `dayInfoText` - Mostra giorno corrente
   - `playerFreqText` - Mostra frequenza player
   - `syncText` - Stato sync (verde/rosso)
   - `collectFeedbackText` - Feedback raccolta oggetti

3. Crea GameObject "UISystem":
   - Aggiungi script **UIManager**
   - Assegna i riferimenti ai TextMeshProUGUI

### 4. Ambiente

**Terreno:**
- Crea Plane (GameObject → 3D Object → Plane)
- Scala: (10, 1, 10)
- Assegna materiale `Ground.mat`

**Cristalli Raccoglibili:**
- Crea Sphere o Cylinder
- Aggiungi script **Collectible3D**
- Imposta `resourceName`, `baseAmount`
- Assegna `normalMaterial` e `syncMaterial`

### 5. Materiali

I materiali sono già inclusi in `Assets/Materials/`:
- **Ground.mat**: Verde per il terreno
- **Crystal_Normal.mat**: Blu per cristalli non-sync
- **Crystal_Sync.mat**: Oro per cristalli in sync

## 🕹️ Controlli

| Tasto | Azione |
|-------|--------|
| Mouse X | Ruota personaggio (asse Y) |
| Mouse Y | Guarda su/giù (camera locale) |
| W/A/S/D | Movimento relativo alla direzione |
| Spazio | Salto |
| Shift | Corsa |
| V | Toggle FPS ↔ TPS |
| E | Raccogli oggetto (distanza 4m) |

## ⚙️ Meccaniche di Gioco

### Resonance System
- Ogni player ha una **Frequency** (1-9) impostabile nell'Inspector
- Il **WorldClock** cicla automaticamente da 1 a 9 ogni 300 secondi
- **IsInSync** = true quando `Frequency == CurrentDay`
- Bonus: **x2 risorse** se in sync, **x1** altrimenti

### Camera System
- **FPS**: Camera a (0, 1.6, 0) locale al player
- **TPS**: Camera orbita dietro al player con LookAt sul busto
- Transizione fluida con Lerp
- Mani visibili in ENTRAMBE le modalità

### Collectibles
- Rotazione continua su asse Y
- Cambiano colore (materiale) se player è in sync
- Raccolta con tasto E (raycast da centro schermo)
- Feedback UI temporaneo con colore condizionale

## ✅ Test di Funzionamento

1. **Play** → Muovi mouse: il personaggio ruota sull'asse Y
2. **WASD** → Movimento nella direzione corretta
3. **Spazio** → Salto con gravità
4. **V** → Transizione fluida FPS/TPS, controllo identico
5. **Mani** → Visibili in entrambe le modalità
6. **Avvicinati a cristallo + E** → Raccolta con bonus x2 se Frequency == WorldDay
7. **UI** → Mostra giorno corrente e stato sync

## 🔧 Note Tecniche

- Tutti gli script usano `FindFirstObjectByType<T>()` per riferimenti runtime
- Singleton pattern con check `Instance != null && Instance != this`
- `IsInSync` è una PROPRIETÀ (chiamare SENZA parentesi: `player.IsInSync`)
- Codice compatibile con Unity 6.3
- Nessun spazio errato in nomi variabili/funzioni
- Indentazione: 4 spazi, no tab

## 📦 Importazione

1. Copia la cartella `Assets` nel tuo progetto Unity
2. Oppure trascina i file direttamente nell'editor Unity
3. Configura la scena seguendo le istruzioni sopra
4. Premi Play!

Buon divertimento con EcoSync! 🎮✨
